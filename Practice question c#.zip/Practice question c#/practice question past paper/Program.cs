﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice_question_past_paper
{
    internal class Program
    {
        //global declarations
        static int pricePaid;
        static Decimal Discount = 0.10m;
        static decimal finalPrice;
        static Decimal discountedPrice;

        //Mainline
        static void Main(string[] args)
        {
            int Input;
            int price = 70;

            Console.WriteLine("Each ticket is R70, how many tickets would you like to buy?");
            Input = Convert.ToInt32(Console.ReadLine());

            // Call method checkTicketBought
            pricePaid = checkTicketBought(Input, price);

            // Loop to see if they qualify for discount
            if (Input <=10)
            {
                // Call method CalculateFinalPrice
                finalPrice = CalculateFinalPrice(pricePaid, Discount);
                Console.ReadLine();

                Console.WriteLine("You qualify for a discount,, your final payment paid is: " + finalPrice);
                Console.ReadLine();
            }
            else
            {
                // Call method CalculateDiscount
                discountedPrice = CalculateDiscount(pricePaid);
                Console.ReadLine();
            }

        }

        // CheckTicketsBought method
        static int checkTicketBought(int input, int price)
        {
            // Calculate price paid
            pricePaid = input * price;
            Console.ReadLine();

            Console.WriteLine("your discount has been calculated");
            return pricePaid;
        }

        // CalculateDiscount method
        static Decimal CalculateDiscount(int pricePaid)
        {
            decimal discountedPrice = (decimal)pricePaid - (decimal)pricePaid * Discount;
            Console.ReadLine();

            Console.WriteLine("your discounted price has been calculated, your discounted price is :"+ discountedPrice);

            return discountedPrice;
        }

        // CalculateFinalPrice method
        static Decimal CalculateFinalPrice(int pricePaid, Decimal discountedPrice)
        {
            decimal finalPrice = (decimal)pricePaid - discountedPrice;
            Console.ReadLine();

            Console.WriteLine("your final price has been calculated");
            return finalPrice;
        }
    }
}
