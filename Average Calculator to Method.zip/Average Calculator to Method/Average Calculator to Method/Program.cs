﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average_Calculator_to_Method
{
    internal class Program
    {
        static int numOne;
        static int numTwo;

        static void Main(string[] args)
        {
            //Declarations
                int finalTotal;

            //will have access to global variabales
            Console.WriteLine("Input your first number");
            numOne = Int32.Parse(Console.ReadLine());

            Console.WriteLine("Input your second number");
            numTwo = Int32.Parse(Console.ReadLine());

            //variable used to get total
            finalTotal = calculation(numOne, numTwo);

            Console.WriteLine("The total of your numbers is:" + finalTotal);

        }
        //declaring the method out the main program
        static int calculation(int numOne, int numTwo)
        {
            //Declarations
                int total;

            total = numOne + numTwo;

            return total;
        }
    }
}

